
package MODELO;

public class Factura {
    
}
